function museum:reset_towers
forceload remove 20 -62 32 -52
scoreboard players set #built museum_init 1
