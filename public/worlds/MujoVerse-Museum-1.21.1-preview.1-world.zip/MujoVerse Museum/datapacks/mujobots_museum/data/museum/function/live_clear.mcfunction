kill @e[type=mujobots:robot,x=34,y=63,z=-82,dx=10,dy=12,dz=16,nbt={robot:"g1"}]
kill @e[type=mujobots:robot,x=34,y=63,z=-82,dx=10,dy=12,dz=16,nbt={robot:"unitree_go1"}]
