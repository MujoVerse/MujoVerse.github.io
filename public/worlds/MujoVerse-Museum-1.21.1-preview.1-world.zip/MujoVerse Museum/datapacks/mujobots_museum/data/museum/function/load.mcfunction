scoreboard objectives add museum_init dummy
execute unless score #built museum_init matches 1 run function museum:init
