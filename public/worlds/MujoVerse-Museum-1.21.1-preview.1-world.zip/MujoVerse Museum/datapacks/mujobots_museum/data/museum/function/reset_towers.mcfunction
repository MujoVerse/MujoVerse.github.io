kill @e[type=mujocraft:structure,x=20,y=65,z=-62,dx=12,dy=20,dz=10]
fill 21 65 -61 31 75 -53 air
clone 20 35 -62 32 43 -52 20 65 -62
mujocraft assemble 22 65 -60 23 70 -59
mujocraft assemble 26 65 -60 27 69 -59
mujocraft assemble 30 65 -60 31 68 -59
mujocraft assemble 22 65 -55 23 67 -54
mujocraft assemble 26 65 -55 27 68 -54
mujocraft assemble 30 65 -55 31 69 -54
