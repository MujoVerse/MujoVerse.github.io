forceload add 20 -62 32 -52
schedule function museum:first_towers 2s
