mujobots walk @e[type=mujobots:robot,x=34,y=63,z=-82,dx=10,dy=12,dz=16,nbt={robot:"g1"}] 0.3 0 0
mujobots walk @e[type=mujobots:robot,x=34,y=63,z=-82,dx=10,dy=12,dz=16,nbt={robot:"unitree_go1"}] 0.35 0 0
